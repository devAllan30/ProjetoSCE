
package View;

import DAO.LojaDAO;
import DTO.LojaDTO;

import javax.swing.JOptionPane;


public class frmCadastrarLoja extends javax.swing.JFrame {

  
    public frmCadastrarLoja() {
        initComponents();
        this.setLocationRelativeTo(null); 
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVoltarMenu = new javax.swing.JButton();
        btnFechar4 = new javax.swing.JButton();
        PainelCadastrar = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTel = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtEnd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtCNPJ = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtCapacidade = new javax.swing.JTextField();
        Limpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnFechar1 = new javax.swing.JButton();
        btnFechar2 = new javax.swing.JButton();
        btnCadastrar = new javax.swing.JButton();
        btnVoltarMenu1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnFechar5 = new javax.swing.JButton();

        btnVoltarMenu.setBackground(new java.awt.Color(153, 153, 153));
        btnVoltarMenu.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnVoltarMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarMenu.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\voltar.png")); // NOI18N
        btnVoltarMenu.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 102, 0)));
        btnVoltarMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltarMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarMenuActionPerformed(evt);
            }
        });

        btnFechar4.setBackground(new java.awt.Color(255, 51, 51));
        btnFechar4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar4.setForeground(new java.awt.Color(255, 255, 255));
        btnFechar4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-multiplicação-24.png")); // NOI18N
        btnFechar4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFechar4ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        PainelCadastrar.setBackground(new java.awt.Color(153, 153, 153));
        PainelCadastrar.setForeground(new java.awt.Color(102, 102, 255));
        PainelCadastrar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nome:");
        PainelCadastrar.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtNome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 160, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Telefone:");
        PainelCadastrar.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        txtTel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 160, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Endereço:");
        PainelCadastrar.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        txtEnd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtEnd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEndActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtEnd, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 160, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("CNPJ:");
        PainelCadastrar.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("E-mail:");
        PainelCadastrar.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, 20));

        txtEmail.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 160, -1));

        txtCNPJ.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtCNPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCNPJActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtCNPJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 160, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Capacidade máxima:");
        PainelCadastrar.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, 20));

        txtCapacidade.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtCapacidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCapacidadeActionPerformed(evt);
            }
        });
        PainelCadastrar.add(txtCapacidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 107, -1));

        Limpar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Limpar.setForeground(new java.awt.Color(255, 0, 0));
        Limpar.setText("Limpar");
        Limpar.setBorder(null);
        Limpar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimparActionPerformed(evt);
            }
        });
        PainelCadastrar.add(Limpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 60, 30));

        btnFechar.setBackground(new java.awt.Color(153, 153, 153));
        btnFechar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar.setForeground(new java.awt.Color(102, 0, 0));
        btnFechar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-macos-close-32.png")); // NOI18N
        btnFechar.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(102, 0, 0)));
        btnFechar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFecharActionPerformed(evt);
            }
        });
        PainelCadastrar.add(btnFechar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 490, 84, -1));

        btnFechar1.setBackground(new java.awt.Color(153, 153, 153));
        btnFechar1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar1.setForeground(new java.awt.Color(102, 0, 0));
        btnFechar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-macos-close-32.png")); // NOI18N
        btnFechar1.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(102, 0, 0)));
        btnFechar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFechar1ActionPerformed(evt);
            }
        });
        PainelCadastrar.add(btnFechar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 490, 84, -1));

        btnFechar2.setBackground(new java.awt.Color(153, 153, 153));
        btnFechar2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar2.setForeground(new java.awt.Color(102, 0, 0));
        btnFechar2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-macos-close-32.png")); // NOI18N
        btnFechar2.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(102, 0, 0)));
        btnFechar2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFechar2ActionPerformed(evt);
            }
        });
        PainelCadastrar.add(btnFechar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 490, 84, -1));

        btnCadastrar.setBackground(new java.awt.Color(153, 153, 153));
        btnCadastrar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnCadastrar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-adicionar-24.png")); // NOI18N
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setBorder(null);
        btnCadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnVoltarMenu1.setBackground(new java.awt.Color(255, 153, 0));
        btnVoltarMenu1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnVoltarMenu1.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarMenu1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-desfazer-24.png")); // NOI18N
        btnVoltarMenu1.setBorder(null);
        btnVoltarMenu1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltarMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarMenu1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 51));
        jLabel2.setText("Cadastrar nova loja:");

        btnFechar5.setBackground(new java.awt.Color(255, 51, 51));
        btnFechar5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar5.setForeground(new java.awt.Color(255, 255, 255));
        btnFechar5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-multiplicação-24.png")); // NOI18N
        btnFechar5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFechar5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel2)
                        .addGap(37, 37, 37)
                        .addComponent(btnVoltarMenu1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnFechar5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(131, 131, 131)
                        .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(PainelCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnVoltarMenu1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnFechar5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2))
                .addGap(30, 30, 30)
                .addComponent(PainelCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelActionPerformed

    private void txtEndActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEndActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEndActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtCNPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCNPJActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCNPJActionPerformed

    private void txtCapacidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCapacidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCapacidadeActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        Cadastrar();
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimparActionPerformed
        LimparCampos1();     // TODO add your handling code here:
    }//GEN-LAST:event_LimparActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnFechar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFechar1ActionPerformed
        dispose();
    }//GEN-LAST:event_btnFechar1ActionPerformed

    private void btnFechar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFechar2ActionPerformed
        dispose();
    }//GEN-LAST:event_btnFechar2ActionPerformed

    private void btnVoltarMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarMenuActionPerformed
        TelaMenu t = new TelaMenu();
        t.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarMenuActionPerformed

    private void btnVoltarMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarMenu1ActionPerformed
        EscolhaLoja t = new EscolhaLoja();
        t.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarMenu1ActionPerformed

    private void btnFechar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFechar4ActionPerformed
        dispose();
    }//GEN-LAST:event_btnFechar4ActionPerformed

    private void btnFechar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFechar5ActionPerformed
        dispose();
    }//GEN-LAST:event_btnFechar5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCadastrarLoja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCadastrarLoja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCadastrarLoja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCadastrarLoja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCadastrarLoja().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Limpar;
    private javax.swing.JPanel PainelCadastrar;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnFechar1;
    private javax.swing.JButton btnFechar2;
    private javax.swing.JButton btnFechar4;
    private javax.swing.JButton btnFechar5;
    private javax.swing.JButton btnVoltarMenu;
    private javax.swing.JButton btnVoltarMenu1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txtCNPJ;
    private javax.swing.JTextField txtCapacidade;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEnd;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTel;
    // End of variables declaration//GEN-END:variables

     private void Cadastrar(){
             String nome, tel, end, email, cnpj, capacidade;
                if(txtNome.getText().isEmpty()  | txtTel.getText().isEmpty()   |  txtEnd.getText().isEmpty()  |  txtEmail.getText().isEmpty() | txtCNPJ.getText().isEmpty() |  txtCapacidade.getText().isEmpty()){
      JOptionPane.showMessageDialog(null,"Preencha todos os campos");
   
     }
     else{
        nome = txtNome.getText();
        tel = txtTel.getText();
        end = txtEnd.getText();
        email = txtEmail.getText();
        cnpj = txtCNPJ.getText();
        capacidade = txtCapacidade.getText();
        
        int c = Integer.parseInt(capacidade);
                       LojaDTO objLDTO = new LojaDTO(); //Instanciei a classe LojaDTO

        objLDTO.setNome(nome);
        objLDTO.setTelefone(tel);
        objLDTO.setEndereco(end);
        objLDTO.setEmail(email);
        objLDTO.setCNPJ(cnpj);
        objLDTO.setCapacidadeEstoque(c);
             
        
        LojaDAO objLDAO = new LojaDAO();
        objLDAO.CadastrarLoja(objLDTO);
               
        JOptionPane.showMessageDialog(null,"Loja cadastrada com sucesso");
        LimparCampos1();
     }
}     private void LimparCampos1(){
         
         txtNome.setText("");
         txtTel.setText("");
         txtEnd.setText("");
         txtEmail.setText("");
         txtCNPJ.setText("");
         txtCapacidade.setText("");
     }
              

}