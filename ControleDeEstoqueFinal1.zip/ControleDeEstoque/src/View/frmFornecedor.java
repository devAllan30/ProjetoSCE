/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import DAO.FornecedorDAO;
import DAO.LojaDAO;

import DTO.FornecedorDTO;
import DTO.LojaAtualDTO;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Allan
 */
public class frmFornecedor extends javax.swing.JFrame {
public void recebendo (String loja){
        txtLojaAtual.setText(loja);}
    /**
     * Creates new form frmFornecedor
     */
    public frmFornecedor() {
        initComponents();
        this.setLocationRelativeTo(null); //Para o Jframe abrir centralizado
        
       
        PainelAtualizar.setVisible(false);
                
        lojaAtual();
        Strings.setVisible(false);
       Listar();
        
       
        
        
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        PainelAtualizar = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtCod = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TXTinsc = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        TXTtel = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        TXTemail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TXTcnpj = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        TXTend = new javax.swing.JTextField();
        Limpar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        TXTnome = new javax.swing.JTextField();
        btnAlterar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        btnVoltarMenu = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        Strings = new javax.swing.JPanel();
        txtLojaAtual = new javax.swing.JLabel();
        L = new javax.swing.JLabel();
        btnExcluir = new javax.swing.JButton();
        btnAtt = new javax.swing.JButton();
        btnAdc = new javax.swing.JButton();
        btnCarregar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNomeFornecedor = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtCNPJFornecedor = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelaFornecedor = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        txtInscFornecedor = new javax.swing.JTextField();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("CDE (Controle de Estoque)");
        setAutoRequestFocus(false);
        setModalExclusionType(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, -1, -1));

        PainelAtualizar.setBackground(new java.awt.Color(153, 153, 153));
        PainelAtualizar.setForeground(new java.awt.Color(255, 255, 255));
        PainelAtualizar.setEnabled(false);
        PainelAtualizar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nome:");
        PainelAtualizar.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        txtCod.setEditable(false);
        txtCod.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtCod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtCod, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 70, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Inscrição estadual:");
        PainelAtualizar.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        TXTinsc.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTinsc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTinscActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTinsc, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 100, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Telefone:");
        PainelAtualizar.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        TXTtel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTtel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTtelActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTtel, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 130, -1));
        PainelAtualizar.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 226, -1, -1));

        TXTemail.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTemailActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, 132, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("E-mail:");
        PainelAtualizar.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("CNPJ:");
        PainelAtualizar.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        TXTcnpj.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTcnpj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTcnpjActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTcnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 130, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Endereço:");
        PainelAtualizar.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, -1));

        TXTend.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTendActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTend, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, 132, -1));

        Limpar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Limpar.setForeground(new java.awt.Color(255, 0, 0));
        Limpar.setText("Limpar");
        Limpar.setBorder(null);
        Limpar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimparActionPerformed(evt);
            }
        });
        PainelAtualizar.add(Limpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 60, 30));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 51));
        PainelAtualizar.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        TXTnome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        TXTnome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTnomeActionPerformed(evt);
            }
        });
        PainelAtualizar.add(TXTnome, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 133, -1));

        btnAlterar.setBackground(new java.awt.Color(153, 153, 153));
        btnAlterar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnAlterar.setForeground(new java.awt.Color(255, 255, 255));
        btnAlterar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-confirmação-e-atualização-24.png")); // NOI18N
        btnAlterar.setText("Alterar");
        btnAlterar.setBorder(null);
        btnAlterar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });
        PainelAtualizar.add(btnAlterar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 160, 50));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Codígo:");
        PainelAtualizar.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        getContentPane().add(PainelAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, 300, 400));

        btnVoltarMenu.setBackground(new java.awt.Color(255, 153, 0));
        btnVoltarMenu.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnVoltarMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarMenu.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-desfazer-24.png")); // NOI18N
        btnVoltarMenu.setBorder(null);
        btnVoltarMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltarMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarMenuActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoltarMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 10, 40, 40));

        btnFechar.setBackground(new java.awt.Color(255, 51, 51));
        btnFechar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar.setForeground(new java.awt.Color(255, 255, 255));
        btnFechar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-multiplicação-24.png")); // NOI18N
        btnFechar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFecharActionPerformed(evt);
            }
        });
        getContentPane().add(btnFechar, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 40, 40));

        L.setText("1");

        javax.swing.GroupLayout StringsLayout = new javax.swing.GroupLayout(Strings);
        Strings.setLayout(StringsLayout);
        StringsLayout.setHorizontalGroup(
            StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, StringsLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(L)
                    .addComponent(txtLojaAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29))
        );
        StringsLayout.setVerticalGroup(
            StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StringsLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(txtLojaAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(Strings, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 530, 70, 40));

        btnExcluir.setBackground(new java.awt.Color(153, 153, 153));
        btnExcluir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(153, 0, 0));
        btnExcluir.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-remover-24.png")); // NOI18N
        btnExcluir.setText("Excluir fornecedor ");
        btnExcluir.setBorder(null);
        btnExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExcluirMouseEntered(evt);
            }
        });
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 420, 180, 30));

        btnAtt.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-sincronizar-24.png")); // NOI18N
        btnAtt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAttMouseEntered(evt);
            }
        });
        btnAtt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAttActionPerformed(evt);
            }
        });
        getContentPane().add(btnAtt, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 40, 30));

        btnAdc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnAdc.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-adicionar-24.png")); // NOI18N
        btnAdc.setBorder(null);
        btnAdc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAdcMouseEntered(evt);
            }
        });
        btnAdc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdcActionPerformed(evt);
            }
        });
        getContentPane().add(btnAdc, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 120, 40, 30));

        btnCarregar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCarregar.setText("Alterar fornecedor selecionado");
        btnCarregar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 51), 3));
        btnCarregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCarregarMouseEntered(evt);
            }
        });
        btnCarregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCarregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 90, 260, 40));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("Busque pelo Inscrição Estadual:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, -1, 20));

        txtNomeFornecedor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNomeFornecedor.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtNomeFornecedorCaretUpdate(evt);
            }
        });
        txtNomeFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeFornecedorActionPerformed(evt);
            }
        });
        getContentPane().add(txtNomeFornecedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 310, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("Busque pelo nome:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, 20));

        txtCNPJFornecedor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtCNPJFornecedor.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtCNPJFornecedorCaretUpdate(evt);
            }
        });
        getContentPane().add(txtCNPJFornecedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 310, -1));

        TabelaFornecedor.setBackground(new java.awt.Color(204, 204, 204));
        TabelaFornecedor.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 102)));
        TabelaFornecedor.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TabelaFornecedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Cod", "Nome", "Inscrição Estadual", "Telefone", "Email", "CNPJ", "Endereço"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabelaFornecedor.setGridColor(new java.awt.Color(204, 0, 0));
        TabelaFornecedor.setSelectionForeground(new java.awt.Color(153, 255, 51));
        jScrollPane2.setViewportView(TabelaFornecedor);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 680, 270));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Busque pelo CNPJ:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, 20));

        txtInscFornecedor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtInscFornecedor.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtInscFornecedorCaretUpdate(evt);
            }
        });
        getContentPane().add(txtInscFornecedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, 220, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TXTemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTemailActionPerformed

    private void TXTinscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTinscActionPerformed
      
    }//GEN-LAST:event_TXTinscActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        CarregarCampos();
        Excluir();
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void TXTtelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTtelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTtelActionPerformed

    private void LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimparActionPerformed
LimparCampos2();     // TODO add your handling code here:
    }//GEN-LAST:event_LimparActionPerformed

    private void TXTcnpjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTcnpjActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTcnpjActionPerformed

    private void TXTendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTendActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTendActionPerformed

    private void txtCodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
     AlterarFornecedor();   // TODO add your handling code here:
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnVoltarMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarMenuActionPerformed
        TelaMenu t = new TelaMenu();
        t.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarMenuActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void TXTnomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTnomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTnomeActionPerformed

    private void btnAttActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAttActionPerformed
        Listar();        // TODO add your handling code here:
    }//GEN-LAST:event_btnAttActionPerformed

    private void btnAdcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdcActionPerformed
        frmCadastroFornecedor f = new frmCadastroFornecedor();
        f.setVisible(true);

        dispose();
    }//GEN-LAST:event_btnAdcActionPerformed

    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed
        CarregarCampos();
        PainelAtualizar.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_btnCarregarActionPerformed

    private void txtNomeFornecedorCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtNomeFornecedorCaretUpdate
        ListarPeloNomeCNPJInsc();
    }//GEN-LAST:event_txtNomeFornecedorCaretUpdate

    private void btnAdcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAdcMouseEntered
btnAdc.setToolTipText("Adicionar novo fornecedor");        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdcMouseEntered

    private void btnAttMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAttMouseEntered
btnAtt.setToolTipText("Atualizar tabela");        // TODO add your handling code here:
    }//GEN-LAST:event_btnAttMouseEntered

    private void btnCarregarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCarregarMouseEntered
btnCarregar.setToolTipText("Selecione um produto na tabela para alterar sua informação");        // TODO add your handling code here:
    }//GEN-LAST:event_btnCarregarMouseEntered

    private void btnExcluirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExcluirMouseEntered
btnExcluir.setToolTipText("Selecione um item na tabela");        // TODO add your handling code here:
    }//GEN-LAST:event_btnExcluirMouseEntered

    private void txtCNPJFornecedorCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtCNPJFornecedorCaretUpdate
ListarPeloNomeCNPJInsc();        // TODO add your handling code here:
    }//GEN-LAST:event_txtCNPJFornecedorCaretUpdate

    private void txtNomeFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeFornecedorActionPerformed

    private void txtInscFornecedorCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtInscFornecedorCaretUpdate
ListarPeloNomeCNPJInsc();        // TODO add your handling code here:
    }//GEN-LAST:event_txtInscFornecedorCaretUpdate

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmFornecedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel L;
    private javax.swing.JButton Limpar;
    private javax.swing.JPanel PainelAtualizar;
    private javax.swing.JPanel Strings;
    private javax.swing.JTextField TXTcnpj;
    private javax.swing.JTextField TXTemail;
    private javax.swing.JTextField TXTend;
    private javax.swing.JTextField TXTinsc;
    private javax.swing.JTextField TXTnome;
    private javax.swing.JTextField TXTtel;
    private javax.swing.JTable TabelaFornecedor;
    private javax.swing.JButton btnAdc;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtt;
    private javax.swing.JButton btnCarregar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnVoltarMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCNPJFornecedor;
    private javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtInscFornecedor;
    private javax.swing.JLabel txtLojaAtual;
    private javax.swing.JTextField txtNomeFornecedor;
    // End of variables declaration//GEN-END:variables


private void LimparCampos2(){
    txtCod.setText("");
    TXTnome.setText("");
    TXTinsc.setText("");
    TXTtel.setText("");
    TXTemail.setText("");
    TXTcnpj.setText("");
    TXTend.setText("");
    PainelAtualizar.setVisible(false);
}




private void AlterarFornecedor(){
    int Cod;
    String nome , insc, tel, email, cnpj, end;
    if(txtCod.getText().isEmpty() | TXTinsc.getText().isEmpty() | TXTtel.getText().isEmpty() | TXTemail.getText().isEmpty() | TXTcnpj.getText().isEmpty() | TXTend.getText().isEmpty()){
        JOptionPane.showMessageDialog(null, "Preencha todos os campos");
    }else{
    Cod = Integer.parseInt(txtCod.getText());
    nome = TXTnome.getText();
    insc = TXTinsc.getText();
    tel = TXTtel.getText();
    email = TXTemail.getText();
    cnpj = TXTcnpj.getText();
    end = TXTend.getText();
    
    FornecedorDTO fDTO = new FornecedorDTO();   
    fDTO.setCod_Fornecedor(Cod);
    fDTO.setNome(nome);
    fDTO.setInsc(insc);
    fDTO.setTel(tel);
    fDTO.setEmail(email);
    fDTO.setCnpj(cnpj);
    fDTO.setEnd(end);
    
    FornecedorDAO fDAO = new FornecedorDAO();
    fDAO.AlterarFornecedor(fDTO);
    JOptionPane.showMessageDialog(null, "Fornecedor alterado com sucesso");
   
    LimparCampos2();
}}

private void Excluir(){
    if(txtCod.getText().isEmpty()){
        JOptionPane.showMessageDialog(null, "Digite um código válido");
    } else{

     int Cod = Integer.parseInt(txtCod.getText());
       FornecedorDTO fDTO = new FornecedorDTO();
       fDTO.setCod_Fornecedor(Cod);
       FornecedorDAO fDAO = new FornecedorDAO();
       fDAO.ExcluirFornecedor(fDTO);
       JOptionPane.showMessageDialog(null, "Fornecedor Excluído");
       LimparCampos2();
}}
private void Listar(){
lojaAtual();

        try {

FornecedorDAO lDAO = new FornecedorDAO();
DefaultTableModel   model =      (DefaultTableModel) TabelaFornecedor.getModel();
model.setNumRows(0);
String NomeLoja = txtLojaAtual.getText();

ArrayList<FornecedorDTO>   ListaInicial = lDAO.ListaTabela(NomeLoja);
for(int num = 0; num < ListaInicial.size(); num++){
    model.addRow(new Object[]{
        ListaInicial.get(num).getCod_Fornecedor(),
        ListaInicial.get(num).getNome(),
        ListaInicial.get(num).getInsc(),
        ListaInicial.get(num).getTel(),
        ListaInicial.get(num).getEmail(),
        ListaInicial.get(num).getCnpj(),
        ListaInicial.get(num).getEnd()
    });
}       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"AlterarLojaDAO" + e);
       }
        
        

    }


 private void lojaAtual(){
    int cod =  Integer.parseInt(L.getText());
    LojaDAO lDAO  = new LojaDAO();
    
    LojaAtualDTO l = lDAO.PegarLoja(cod);
  
   txtLojaAtual.setText(l.getLoja());
    
 
   
 }
 private void ListarPeloNomeCNPJInsc(){
lojaAtual();

        try {

FornecedorDAO lDAO = new FornecedorDAO();
DefaultTableModel   model =      (DefaultTableModel) TabelaFornecedor.getModel();
model.setNumRows(0);
String NomeLoja = txtLojaAtual.getText();
String NomeFornecedor = txtNomeFornecedor.getText();
String CNPJ = txtCNPJFornecedor.getText();
String Insc = txtInscFornecedor.getText();
ArrayList<FornecedorDTO>   ListaInicial = lDAO.ListaTabelaPeloNomeCNPJ(NomeLoja, NomeFornecedor, CNPJ, Insc);
for(int num = 0; num < ListaInicial.size(); num++){
    model.addRow(new Object[]{
ListaInicial.get(num).getCod_Fornecedor(),
        ListaInicial.get(num).getNome(),
        ListaInicial.get(num).getInsc(),
        ListaInicial.get(num).getTel(),
        ListaInicial.get(num).getEmail(),
        ListaInicial.get(num).getCnpj(),
        ListaInicial.get(num).getEnd()
    });
}       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"AlterarLojaDAO" + e);
       }
        
        

    }

 
   private void  CarregarCampos(){
           int setar = TabelaFornecedor.getSelectedRow();
       
       
                txtCod.setText(TabelaFornecedor.getModel().getValueAt(setar, 0).toString());
                TXTnome.setText(TabelaFornecedor.getModel().getValueAt(setar, 1).toString());
                TXTinsc.setText(TabelaFornecedor.getModel().getValueAt(setar,2).toString());
                TXTtel.setText(TabelaFornecedor.getModel().getValueAt(setar, 3).toString());
                TXTemail.setText(TabelaFornecedor.getModel().getValueAt(setar, 4).toString());
                TXTcnpj.setText(TabelaFornecedor.getModel().getValueAt(setar, 5).toString());
                TXTend.setText(TabelaFornecedor.getModel().getValueAt(setar, 6).toString());
        }
}
