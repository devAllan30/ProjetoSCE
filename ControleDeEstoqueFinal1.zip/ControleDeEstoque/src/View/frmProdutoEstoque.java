
package View;


import DAO.ConexaoDAO;
import DAO.FornecedorDAO;

import DAO.LojaDAO;
import DAO.ProdutoDAO;
import DTO.ListarDTO;
import DTO.LojaAtualDTO;
import DTO.LojaDTO;
import DTO.ProdutoDTO;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class frmProdutoEstoque extends javax.swing.JFrame {
frmEntradaSaida envia;
    
    public frmProdutoEstoque() {
        initComponents();
        this.setLocationRelativeTo(null); 
        
        Listar();
       
        PainelAtualizar.setVisible(false);
        Strings.setVisible(false);
        ListarComboCat();
       
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaProduto = new javax.swing.JTable();
        btnVoltarMenu = new javax.swing.JButton();
        btnFechar1 = new javax.swing.JButton();
        btnCarregar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        PainelAtualizar = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtMarca = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtQtde = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtPreco = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtFornecedor = new javax.swing.JTextField();
        btnAlterar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtCod = new javax.swing.JTextField();
        cbCategoria = new javax.swing.JComboBox<>();
        btnCadastrar = new javax.swing.JButton();
        Strings = new javax.swing.JPanel();
        L1 = new javax.swing.JLabel();
        txtLcap = new javax.swing.JLabel();
        txtLtotal = new javax.swing.JLabel();
        L = new javax.swing.JLabel();
        txtLojaAtual1 = new javax.swing.JLabel();
        btnES = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtNomeProduto = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtLojaAtual = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtTipoBusca = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabelaProduto.setBackground(new java.awt.Color(204, 204, 204));
        TabelaProduto.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 102)));
        TabelaProduto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TabelaProduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Cod", "Nome", "Categoria", "Marca", "Quantidade", "Preço", "Fornecedor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabelaProduto.setGridColor(new java.awt.Color(204, 0, 0));
        TabelaProduto.setSelectionForeground(new java.awt.Color(153, 255, 51));
        jScrollPane1.setViewportView(TabelaProduto);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 690, 330));

        btnVoltarMenu.setBackground(new java.awt.Color(255, 153, 0));
        btnVoltarMenu.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnVoltarMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarMenu.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-desfazer-24.png")); // NOI18N
        btnVoltarMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarMenuActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoltarMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 10, 40, 36));

        btnFechar1.setBackground(new java.awt.Color(255, 51, 51));
        btnFechar1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnFechar1.setForeground(new java.awt.Color(255, 255, 255));
        btnFechar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-multiplicação-24.png")); // NOI18N
        btnFechar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFechar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFechar1ActionPerformed(evt);
            }
        });
        getContentPane().add(btnFechar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 10, 40, 36));

        btnCarregar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCarregar.setText("Alterar produto selecionado");
        btnCarregar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 51), 3));
        btnCarregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCarregarMouseEntered(evt);
            }
        });
        btnCarregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCarregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 100, 260, 40));

        btnExcluir.setBackground(new java.awt.Color(153, 153, 153));
        btnExcluir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(153, 0, 0));
        btnExcluir.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-remover-24.png")); // NOI18N
        btnExcluir.setText("Excluir produto ");
        btnExcluir.setBorder(null);
        btnExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExcluirMouseEntered(evt);
            }
        });
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 460, 190, 30));

        btnAtualizar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-sincronizar-24.png")); // NOI18N
        btnAtualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAtualizarMouseEntered(evt);
            }
        });
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 100, 40, 30));

        PainelAtualizar.setBackground(new java.awt.Color(153, 153, 153));
        PainelAtualizar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Codígo:");
        PainelAtualizar.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 11, -1, -1));

        txtNome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 40, 140, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Categoria:");
        PainelAtualizar.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 87, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Marca:");
        PainelAtualizar.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 128, -1, -1));

        txtMarca.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMarcaActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 122, 140, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantidade:");
        PainelAtualizar.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 169, -1, -1));

        txtQtde.setEditable(false);
        txtQtde.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtQtde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQtdeActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtQtde, new org.netbeans.lib.awtextra.AbsoluteConstraints(128, 163, 120, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Preço:");
        PainelAtualizar.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 207, -1, -1));

        txtPreco.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtPreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecoActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtPreco, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 204, 120, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Fornecedor:");
        PainelAtualizar.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 248, -1, -1));

        txtFornecedor.setEditable(false);
        txtFornecedor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFornecedorActionPerformed(evt);
            }
        });
        PainelAtualizar.add(txtFornecedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 245, 110, -1));

        btnAlterar.setBackground(new java.awt.Color(153, 153, 153));
        btnAlterar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnAlterar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-confirmação-e-atualização-24.png")); // NOI18N
        btnAlterar.setText("Confirmar");
        btnAlterar.setBorder(null);
        btnAlterar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });
        PainelAtualizar.add(btnAlterar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 200, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Nome:");
        PainelAtualizar.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 43, -1, -1));

        txtCod.setEditable(false);
        txtCod.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PainelAtualizar.add(txtCod, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 11, 47, -1));

        cbCategoria.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PainelAtualizar.add(cbCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 87, 140, -1));

        getContentPane().add(PainelAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 170, 270, 360));

        btnCadastrar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCadastrar.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-adicionar-24.png")); // NOI18N
        btnCadastrar.setBorder(null);
        btnCadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseEntered(evt);
            }
        });
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 100, 40, 30));

        L1.setText("1");

        txtLcap.setText("jLabel1");

        txtLtotal.setText("jLabel1");

        L.setText("1");

        txtLojaAtual1.setText("jLabel15");

        javax.swing.GroupLayout StringsLayout = new javax.swing.GroupLayout(Strings);
        Strings.setLayout(StringsLayout);
        StringsLayout.setHorizontalGroup(
            StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StringsLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(L)
                .addGroup(StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(StringsLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(L1)
                        .addGap(18, 18, 18)
                        .addComponent(txtLcap))
                    .addGroup(StringsLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtLojaAtual1)
                        .addGap(24, 24, 24)
                        .addComponent(txtLtotal)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        StringsLayout.setVerticalGroup(
            StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StringsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLtotal)
                    .addComponent(txtLojaAtual1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(StringsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(L1)
                    .addComponent(txtLcap, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(StringsLayout.createSequentialGroup()
                .addComponent(L)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(Strings, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 540, 98, -1));

        btnES.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnES.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-transição-em-ambos-os-sentidos-24.png")); // NOI18N
        btnES.setText("E/S");
        btnES.setBorder(null);
        btnES.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnES.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnESMouseEntered(evt);
            }
        });
        btnES.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnESActionPerformed(evt);
            }
        });
        getContentPane().add(btnES, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, 60, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Buscar pelo nome:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 20));

        txtNomeProduto.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNomeProduto.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtNomeProdutoCaretUpdate(evt);
            }
        });
        getContentPane().add(txtNomeProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 210, -1));

        jButton5.setBackground(new java.awt.Color(153, 153, 153));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Allan\\Downloads\\icons8-relatório-gráfico-24.png")); // NOI18N
        jButton5.setText("Relatório do estoque");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 51), 2));
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 230, 40));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 51));
        jLabel11.setText("Produtos em Estoque da loja:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, -1, -1));

        txtLojaAtual.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtLojaAtual.setForeground(new java.awt.Color(0, 0, 51));
        txtLojaAtual.setText("jLabel2");
        getContentPane().add(txtLojaAtual, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 30, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Buscar pela categoria:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        txtTipoBusca.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtTipoBusca.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtTipoBuscaCaretUpdate(evt);
            }
        });
        txtTipoBusca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoBuscaActionPerformed(evt);
            }
        });
        getContentPane().add(txtTipoBusca, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 210, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarMenuActionPerformed
        TelaMenu r = new TelaMenu();
        r.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarMenuActionPerformed

    private void btnFechar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFechar1ActionPerformed
        dispose();
    }//GEN-LAST:event_btnFechar1ActionPerformed

    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed
CarregarCampos();
        if(txtNome.getText().isEmpty()){
   JOptionPane.showMessageDialog(null, "Selecione um item na tabela");
}else{
        
        
PainelAtualizar.setVisible(true);
}// TODO add your handling code here:
    }//GEN-LAST:event_btnCarregarActionPerformed

    private void txtMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMarcaActionPerformed

    private void txtQtdeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQtdeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeActionPerformed

    private void txtPrecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecoActionPerformed

    private void txtFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFornecedorActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
Alterar();   // TODO add your handling code here:
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
CarregarCampos();

            Excluir();
            

 
        
        

        
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        Listar();     
        txtNomeProduto.setText("");
        txtTipoBusca.setText("");
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed

        frmCadastroProduto f = new frmCadastroProduto();
        f.setVisible(true);

        dispose();

    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnESActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnESActionPerformed

        
        CarregarCampos();
      
        if(envia == null){
    envia = new frmEntradaSaida();
    envia.setVisible(true);
    envia.recebe(txtNome.getText());
    dispose();
}else{
    envia.setVisible(true);
    envia.setState(frmEntradaSaida.NORMAL);
     envia.recebe(txtNome.getText());
        dispose();
        }
        
    }//GEN-LAST:event_btnESActionPerformed

    private void txtNomeProdutoCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtNomeProdutoCaretUpdate
ListarPeloNomeCategoria();
    }//GEN-LAST:event_txtNomeProdutoCaretUpdate

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
frmRelatorio r = new frmRelatorio();
r.setVisible(true);     
dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnCadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseEntered
btnCadastrar.setToolTipText("Adicionar novos produtos");        // TODO add your handling code here:
    }//GEN-LAST:event_btnCadastrarMouseEntered

    private void btnAtualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAtualizarMouseEntered
btnAtualizar.setToolTipText("Atualizar tabela");       
    }//GEN-LAST:event_btnAtualizarMouseEntered

    private void btnCarregarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCarregarMouseEntered
  btnCarregar.setToolTipText("Selecione um produto na tabela para alterar sua informação");      // TODO add your handling code here:
    }//GEN-LAST:event_btnCarregarMouseEntered

    private void btnExcluirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExcluirMouseEntered
btnExcluir.setToolTipText("Selecione um item na tabela");       
    }//GEN-LAST:event_btnExcluirMouseEntered

    private void txtTipoBuscaCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtTipoBuscaCaretUpdate
ListarPeloNomeCategoria();        
    }//GEN-LAST:event_txtTipoBuscaCaretUpdate

    private void btnESMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnESMouseEntered
btnES.setToolTipText("Selecione um produto na tabela para controlar sua entrada e saída ");        // TODO add your handling code here:
    }//GEN-LAST:event_btnESMouseEntered

    private void txtTipoBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoBuscaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoBuscaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmProdutoEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmProdutoEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmProdutoEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmProdutoEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmProdutoEstoque().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel L;
    private javax.swing.JLabel L1;
    private javax.swing.JPanel PainelAtualizar;
    private javax.swing.JPanel Strings;
    private javax.swing.JTable TabelaProduto;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnCarregar;
    private javax.swing.JButton btnES;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar1;
    private javax.swing.JButton btnVoltarMenu;
    private javax.swing.JComboBox<String> cbCategoria;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtFornecedor;
    private javax.swing.JLabel txtLcap;
    private javax.swing.JLabel txtLojaAtual;
    private javax.swing.JLabel txtLojaAtual1;
    private javax.swing.JLabel txtLtotal;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtPreco;
    private javax.swing.JTextField txtQtde;
    private javax.swing.JTextField txtTipoBusca;
    // End of variables declaration//GEN-END:variables
private void Listar(){
lojaAtual();
        try {

ProdutoDAO lDAO = new ProdutoDAO();
DefaultTableModel   model =      (DefaultTableModel) TabelaProduto.getModel();
model.setNumRows(0);
String NomeLoja = txtLojaAtual.getText();

ArrayList<ProdutoDTO>   ListaInicial = lDAO.ListaTabela(NomeLoja);
for(int num = 0; num < ListaInicial.size(); num++){
    model.addRow(new Object[]{
        ListaInicial.get(num).getCod_Produto(),
        ListaInicial.get(num).getNome(),
        ListaInicial.get(num).getCategoria(),
        ListaInicial.get(num).getMarca(),
        ListaInicial.get(num).getQtde_Em_Estoque(),
        ListaInicial.get(num).getPreco(),
        ListaInicial.get(num).getFornecedor()
    });
}       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"AlterarLojaDAO" + e);
       }
        
        

    }
 


private void ListarPeloNomeCategoria(){
lojaAtual();

        try {

ProdutoDAO lDAO = new ProdutoDAO();

DefaultTableModel   model =      (DefaultTableModel) TabelaProduto.getModel();
model.setNumRows(0);
String Categoria = (String) txtTipoBusca.getText();
String NomeLoja = txtLojaAtual.getText();
String NomeProduto = txtNomeProduto.getText();
ArrayList<ProdutoDTO>   ListaInicial = lDAO.ListaTabelaPeloNomeTipo(NomeLoja, NomeProduto, Categoria);
for(int num = 0; num < ListaInicial.size(); num++){
    model.addRow(new Object[]{
        ListaInicial.get(num).getCod_Produto(),
        ListaInicial.get(num).getNome(),
        ListaInicial.get(num).getCategoria(),
        ListaInicial.get(num).getMarca(),
        ListaInicial.get(num).getQtde_Em_Estoque(),
        ListaInicial.get(num).getPreco(),
        ListaInicial.get(num).getFornecedor()
    });
}       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"AlterarLojaDAO" + e);
       }
        
        

    }


private void lojaAtual(){
    int cod =  Integer.parseInt(L.getText());
    LojaDAO lDAO  = new LojaDAO();
    
    LojaAtualDTO l = lDAO.PegarLoja(cod);
  
   txtLojaAtual.setText(l.getLoja());
    
}


 



    private void  CarregarCampos(){
           int setar = TabelaProduto.getSelectedRow();
       
       
                txtCod.setText(TabelaProduto.getModel().getValueAt(setar, 0).toString());
                txtNome.setText(TabelaProduto.getModel().getValueAt(setar, 1).toString());
               cbCategoria.setSelectedItem(TabelaProduto.getModel().getValueAt(setar,2).toString());
                txtMarca.setText(TabelaProduto.getModel().getValueAt(setar, 3).toString());
                txtQtde.setText(TabelaProduto.getModel().getValueAt(setar, 4).toString());
                txtPreco.setText(TabelaProduto.getModel().getValueAt(setar, 5).toString());
                txtFornecedor.setText(TabelaProduto.getModel().getValueAt(setar, 6).toString());
        }
    

       private void Excluir() {

            CarregarCampos();
            String Nome;              //Criando uma variavel cod
            Nome = (String) txtNome.getText();       //atribui a variavel cod ao que o usuario
            ProdutoDTO pDTO = new ProdutoDTO();  //Instanciei ProdutoDTO criando o objeto pDTO

            pDTO.setNome(Nome);      //chamei o obj e levei a variavel cod pra variavel da dto
            ProdutoDAO pDAO = new ProdutoDAO();
            pDAO.ExcluirProduto(pDTO);
            JOptionPane.showMessageDialog(null, "Produto Excluído");
            

        }
        
        
       
        
       
       
        private void Alterar() {
           
        

       
           
         if ( txtCod.getText().isEmpty() | txtMarca.getText().isEmpty() | txtQtde.getText().isEmpty() | txtNome.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Preencha todos os campos");

        } else {
            
            int cod, qtde;
            String nome, tipo, marca, preco;
            
            cod = Integer.parseInt(txtCod.getText());
            nome = txtNome.getText();
            tipo = (String) cbCategoria.getSelectedItem();
            marca = txtMarca.getText();
            preco = txtPreco.getText();
            qtde = Integer.parseInt(txtQtde.getText());
            
            ProdutoDTO pDTO = new ProdutoDTO();
            pDTO.setCod_Produto(cod);
            pDTO.setNome(nome);
            pDTO.setCategoria(tipo);
            pDTO.setMarca(marca);
            pDTO.setPreco(preco);
            pDTO.setQtde_Em_Estoque(qtde);
            
            ProdutoDAO pDAO = new ProdutoDAO();
            pDAO.AlterarFornecedor(pDTO);
            LimparCampos();
            
            

     
    }

        }
        
        
        
        
        private void LimparCampos(){
            txtCod.setText("");
            txtNome.setText("");
            txtMarca.setText("");
            txtPreco.setText("");
            txtQtde.setText("");
            txtFornecedor.setText("");
            PainelAtualizar.setVisible(false);
}
        public ResultSet ListarCat(){
      lojaAtual();
       Connection conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM Categoria  where NomeLoja = ? ORDER BY Descricao";
        
        try {
           PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, txtLojaAtual.getText());
            return pstm.executeQuery();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
        return null;


        
    }
      public void ListarComboCat() {
        lojaAtual();
        try {
          
            
           ResultSet rs = ListarCat();

            while (rs.next()) {
               
                cbCategoria.addItem(rs.getString(2));
            }
                
        } catch (Exception e) {
        }} 
        
}


