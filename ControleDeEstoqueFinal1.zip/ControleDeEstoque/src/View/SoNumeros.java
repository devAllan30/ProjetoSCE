
package View;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;


public class SoNumeros extends PlainDocument {     //Classe para formatar os campos de textos para ser digitados em apenas num

    @Override
    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
        
        super.insertString(offs, str.replaceAll("[^0-9]", "" ), a); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
