
package DTO;


public class FornecedorDTO {
    private int Cod_Fornecedor;
    private String nome;
    private String insc;
    private String tel;
    private String email;
    private String cnpj;
    private String end, lojaAtual;

    public int getCod_Fornecedor() {
        return Cod_Fornecedor;
    }

    public void setCod_Fornecedor(int Cod_Fornecedor) {
        this.Cod_Fornecedor = Cod_Fornecedor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getInsc() {
        return insc;
    }

    public void setInsc(String insc) {
        this.insc = insc;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getLojaAtual() {
        return lojaAtual;
    }

    public void setLojaAtual(String lojaAtual) {
        this.lojaAtual = lojaAtual;
    }
}
