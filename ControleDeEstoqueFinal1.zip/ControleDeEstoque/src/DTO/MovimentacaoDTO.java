
package DTO;

import java.util.Date;

public class MovimentacaoDTO {
    private String NomeProduto, tipo, Data, loja;
    private int Cod_Movimentacao, qtde, SaidaQdte, NomeProdutoSaida;
    
  

    public String getNomeProduto() {
        return NomeProduto;
    }

    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }


    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public int getCod_Movimentacao() {
        return Cod_Movimentacao;
    }

    public void setCod_Movimentacao(int Cod_Movimentacao) {
        this.Cod_Movimentacao = Cod_Movimentacao;
    }

    public String getLoja() {
        return loja;
    }

    public void setLoja(String loja) {
        this.loja = loja;
    }

    public int getSaidaQdte() {
        return SaidaQdte;
    }

    public void setSaidaQdte(int SaidaQdte) {
        this.SaidaQdte = SaidaQdte;
    }

    public int getNomeProdutoSaida() {
        return NomeProdutoSaida;
    }

    public void setNomeProdutoSaida(int NomeProdutoSaida) {
        this.NomeProdutoSaida = NomeProdutoSaida;
    }
}
