
package DTO;

import java.math.BigDecimal;


public class ProdutoDTO {
    private int Cod_Produto, Qtde_Em_Estoque, qtde;
    private String nome, categoria, marca, preco, fornecedor, lojaAtual;
  

    public int getCod_Produto() {
        return Cod_Produto;
    }

    public void setCod_Produto(int Cod_Produto) {
        this.Cod_Produto = Cod_Produto;
    }

    public int getQtde_Em_Estoque() {
        return Qtde_Em_Estoque;
    }

    public void setQtde_Em_Estoque(int Qtde_Em_Estoque) {
        this.Qtde_Em_Estoque = Qtde_Em_Estoque;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

  

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getLojaAtual() {
        return lojaAtual;
    }

    public void setLojaAtual(String lojaAtual) {
        this.lojaAtual = lojaAtual;
    }

    public void getCod_Produto(int Cod) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

   

   

    
    
}
