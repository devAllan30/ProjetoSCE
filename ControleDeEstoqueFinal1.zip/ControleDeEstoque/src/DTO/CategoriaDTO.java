
package DTO;


public class CategoriaDTO {
    private String Descricao, lojaatual;

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    public String getLojaatual() {
        return lojaatual;
    }

    public void setLojaatual(String lojaatual) {
        this.lojaatual = lojaatual;
    }
}
