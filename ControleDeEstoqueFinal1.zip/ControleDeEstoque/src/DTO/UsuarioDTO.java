
package DTO;


public class UsuarioDTO {
    private int Cod_Uuario;
    private String Login, Senha;

    public int getCod_Uuario() {
        return Cod_Uuario;
    }

    public void setCod_Uuario(int Cod_Uuario) {
        this.Cod_Uuario = Cod_Uuario;
    }

    public String getLogin() {
        return Login;
    }

    public void setLogin(String Login) {
        this.Login = Login;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }
    
}
