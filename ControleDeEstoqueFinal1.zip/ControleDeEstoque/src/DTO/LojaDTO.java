
package DTO;


public class LojaDTO {
    private int Cod_Loja, CapacidadeEstoque;
    private String Nome;
    private String Telefone;
    private String Endereco;
    private String Email;
    private String CNPJ;
    private String LojaEstoqueAtual;

    public int getCod_Loja() {
        return Cod_Loja;
    }

    public void setCod_Loja(int Cod_Loja) {
        this.Cod_Loja = Cod_Loja;
    }

    public int getCapacidadeEstoque() {
        return CapacidadeEstoque;
    }

    public void setCapacidadeEstoque(int CapacidadeEstoque) {
        this.CapacidadeEstoque = CapacidadeEstoque;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getLojaEstoqueAtual() {
        return LojaEstoqueAtual;
    }

    public void setLojaEstoqueAtual(String LojaEstoqueAtual) {
        this.LojaEstoqueAtual = LojaEstoqueAtual;
    }

  
}
