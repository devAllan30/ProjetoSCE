
package DAO;


import DTO.LojaDTO;
import DTO.MovimentacaoDTO;
import DTO.ProdutoDTO;
import View.frmEntradaSaida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class ProdutoDAO {
     Connection conn;
     PreparedStatement pstm;
     ResultSet rs;
     ArrayList<ProdutoDTO> listaInicial = new ArrayList<>();

    public void CadastrarProduto (ProdutoDTO objpDTO){     //Metodo de cadastrar chamando a classe e os seu objeto
       String sql = "insert into Produto (Nome, Categoria, Marca, Preco, Qtde_Em_Estoque, NomeLoja, NomeFornecedor) values (?, ?, ?, ?, ?, ?, ?)"; //String de para inserir os valores na tabela
       conn = new ConexaoDAO().conectaBD(); //chamando a conexao
       
       try {
           pstm = conn.prepareStatement(sql); //preparando a conexao e passando a string como parametro
           LojaDTO l = new LojaDTO();
           pstm.setString(1, objpDTO.getNome()); //setando os valores na tabela
           pstm.setString(2, objpDTO.getCategoria()); 
           pstm.setString(3, objpDTO.getMarca());
           pstm.setString(4, objpDTO.getPreco());
           pstm.setInt(5, objpDTO.getQtde_Em_Estoque());         
           pstm.setString(6, objpDTO.getLojaAtual());
           pstm.setString(7, objpDTO.getFornecedor());
           
           pstm.execute();   //Executando 
           pstm.close();     //Fechando
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"ProdutoDAO" + e);
       }
    }

         public ProdutoDTO PesquisarProduto(String Nome){
          String sql = "SELECT * FROM Produto WHERE Nome = ?";
          
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = this.conn.prepareStatement(sql);
              pstm.setString(1, Nome);
              rs = pstm.executeQuery();
              
              ProdutoDTO pDTO = new ProdutoDTO();
              rs.first();
              if(rs.first()){
              
              pDTO.setNome(rs.getString("Nome"));
              pDTO.setCategoria(rs.getString("Categoria"));
              pDTO.setMarca(rs.getString("Marca"));
              pDTO.setQtde_Em_Estoque(rs.getInt("Qtde_Em_Estoque"));
              pDTO.setPreco(rs.getString("Preco"));
              pDTO.setFornecedor(rs.getString("NomeFornecedor"));
              return pDTO;
              
              }else{
                  JOptionPane.showMessageDialog(null, "Produto não encontrado");
                  
                  
              }
          } catch (Exception e) {
              return null;
          }
         return null;
          
      }  
           
           
           public void ExcluirProduto(ProdutoDTO pDTO){
          String sql = "DElETE  FROM Produto WHERE Nome = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              
              pstm.setString(1, pDTO.getNome());
              
              pstm.execute();
              pstm.close();
              
              
              
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
          }
          
      }

       
         public void AlterarFornecedor(ProdutoDTO objpDTO){
               String sql = "update Produto set Nome = ?, Categoria = ?, Marca = ?, Preco = ?, Qtde_Em_Estoque = ? where Cod_Produto = ?";
               conn = new ConexaoDAO().conectaBD();
       
       try {
           
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, objpDTO.getNome());
           pstm.setString(2, objpDTO.getCategoria());
           pstm.setString(3, objpDTO.getMarca());
           pstm.setString(4, objpDTO.getPreco());
           pstm.setInt(5, objpDTO.getQtde_Em_Estoque());
           pstm.setInt(6, objpDTO.getCod_Produto());
           
           JOptionPane.showMessageDialog(null, "Produto Alterado");
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"ProdutoDAO" + e);
       }
   }
   
 public ArrayList  <ProdutoDTO> ListaTabela(String NomeLoja){
        String sql = "select * from Produto where NomeLoja = ?";
        conn = new ConexaoDAO().conectaBD();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, NomeLoja);
           
            rs = pstm.executeQuery();
            
            while(rs.next()){
                ProdutoDTO pDTO = new ProdutoDTO();
                pDTO.setCod_Produto(rs.getInt("Cod_Produto"));
                pDTO.setNome(rs.getString("Nome"));
                pDTO.setCategoria(rs.getString("Categoria"));
                pDTO.setMarca(rs.getString("Marca"));
                pDTO.setQtde_Em_Estoque(rs.getInt("Qtde_Em_Estoque"));
                pDTO.setPreco(rs.getString("Preco"));
                pDTO.setFornecedor(rs.getString("NomeFornecedor"));
              listaInicial.add(pDTO);
                
                
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return listaInicial;
    }
    

    
        public void ExcluirProdutoLoja(ProdutoDTO pDTO){
          String sql = "DElETE  FROM Produto WHERE NomeLoja = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              
              pstm.setString(1, pDTO.getLojaAtual());
              
              pstm.execute();
              pstm.close();
              
              
              
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
          }
          
          
      }
      
    
    
    

    public ResultSet ListarProdutos(String NomeLoja ) {
        conn = new ConexaoDAO().conectaBD();
        String sql = " SELECT * FROM Produto WHERE NomeLoja = ? ORDER BY Nome";

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setString(1, NomeLoja);
            pstm.executeQuery();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }
      public ArrayList  <ProdutoDTO> ListaTabelaPeloNomeTipo(String NomeLoja,String Nome, String Categoria){
        String sql = "select * from Produto where NomeLoja = ? and Nome LIKE ? and Categoria LIKE ?";
        conn = new ConexaoDAO().conectaBD();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, NomeLoja);
            pstm.setString(2, "%"+Nome+"%");
            pstm.setString(3, "%"+Categoria+"%");
            
            
            rs = pstm.executeQuery();
            
            while(rs.next()){
                ProdutoDTO pDTO = new ProdutoDTO();
                pDTO.setCod_Produto(rs.getInt("Cod_Produto"));
                pDTO.setNome(rs.getString("Nome"));
                pDTO.setCategoria(rs.getString("Categoria"));
                pDTO.setMarca(rs.getString("Marca"));
                pDTO.setQtde_Em_Estoque(rs.getInt("Qtde_Em_Estoque"));
                pDTO.setPreco(rs.getString("Preco"));
                pDTO.setFornecedor(rs.getString("NomeFornecedor"));
              listaInicial.add(pDTO);
                
                
            }
            
        } catch (Exception e) {
        }
        return listaInicial;
    
      } 
      
        public ArrayList  <ProdutoDTO>  ListarQtdeCategoria(String NomeLoja){
          String sql = "Select sum(Qtde_Em_Estoque), Categoria from Produto where  NomeLoja = ?  group by Categoria order by 1 desc";
          
     conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                
                
                pstm.setString(1, NomeLoja);



                rs = pstm.executeQuery();
                
                while(rs.next()){
                    ProdutoDTO pDTO = new ProdutoDTO();
                   pDTO.setQtde_Em_Estoque(rs.getInt("sum(Qtde_Em_Estoque)"));
                    pDTO.setCategoria(rs.getString("Categoria"));
                   
                    
                    
                    
                    listaInicial.add(pDTO);
                    
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return listaInicial;
        }
        
        
        public ArrayList  <ProdutoDTO>  ListarFiltroQtdeCategoria(String NomeLoja, String Categoria){
          String sql = "Select sum(Qtde_Em_Estoque), Categoria from Produto where  NomeLoja = ? and Categoria LIKE ? group by Categoria order by 1 desc";
          
     conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                
                
                pstm.setString(1, NomeLoja);
                pstm.setString(2, "%"+Categoria+"%");



                rs = pstm.executeQuery();
                
                while(rs.next()){
                    ProdutoDTO pDTO = new ProdutoDTO();
                   pDTO.setQtde_Em_Estoque(rs.getInt("sum(Qtde_Em_Estoque)"));
                    pDTO.setCategoria(rs.getString("Categoria"));
                   
                    
                    
                    
                    listaInicial.add(pDTO);
                    
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return listaInicial;
        }
        
    
}
