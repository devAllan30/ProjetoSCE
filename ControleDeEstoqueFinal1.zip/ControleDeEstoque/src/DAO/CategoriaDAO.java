
package DAO;

import DTO.CategoriaDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class CategoriaDAO {
    
    
       Connection conn;
     PreparedStatement pstm;
     ResultSet rs;
   

    public void CadastrarCategoria (CategoriaDTO cDTO){     //Metodo de cadastrar chamando a classe e os seu objeto
       String sql = "insert into Categoria (Descricao, NomeLoja) values (?, ?)"; //String de para inserir os valores na tabela
       conn = new ConexaoDAO().conectaBD(); //chamando a conexao
       
       try {
           pstm = conn.prepareStatement(sql); //preparando a conexao e passando a string como parametro
          
           pstm.setString(1, cDTO.getDescricao()); 
           pstm.setString(2, cDTO.getLojaatual());

           
           
           pstm.execute();   //Executando 
           pstm.close();     //Fechando
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"ProdutoDAO" + e);
       }
    }
    
        public ResultSet ListarCategoria(){
        conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM Categoria where NomeLoja = ? ORDER BY Descricao ";
        try {
            CategoriaDTO f = new CategoriaDTO();
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, f.getLojaatual());
            return pstm.executeQuery();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
return null;
    }
    public void ExcluirCategoria(CategoriaDTO c){
        conn = new ConexaoDAO().conectaBD();
        String sql = "DElETE  FROM Categoria WHERE Descricao = ? and NomeLoja = ?";
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, c.getDescricao());
            pstm.setString(2, c.getLojaatual());
                pstm.execute();
              pstm.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
        public void ExcluirCategoriaProduto(CategoriaDTO c){
        conn = new ConexaoDAO().conectaBD();
        String sql = "DElETE  FROM Produto WHERE Categoria = ? and NomeLoja = ?";
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, c.getDescricao());
            pstm.setString(2, c.getLojaatual());
                pstm.execute();
              pstm.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
