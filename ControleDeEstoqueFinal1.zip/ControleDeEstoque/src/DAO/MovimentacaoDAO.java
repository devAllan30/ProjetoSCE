
package DAO;

import DTO.MovimentacaoDTO;
import DTO.ProdutoDTO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class MovimentacaoDAO {
       Connection conn;
    PreparedStatement pstm;
      ResultSet rs;
   public void CadastrarMovimentacao (MovimentacaoDTO mDTO){
       String sql = "insert into Movimentacoes (NomeProduto, Quantidade, Tipo, NomeLoja) values (?, ?, ?, ?) ";
       conn = new ConexaoDAO().conectaBD();
       
       try {
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, mDTO.getNomeProduto());
           pstm.setInt(2, mDTO.getQtde());
           pstm.setString(3, mDTO.getTipo());
           pstm.setString(4, mDTO.getLoja());
           
           
           
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"FuncionarioDAO" + e);
       }
   }
   
   
       
     ArrayList<MovimentacaoDTO> lista = new ArrayList<>();
        


     
        public ArrayList<MovimentacaoDTO> ListarMovimentacao(String NomeLoja){
 
            String sql = "Select * from Movimentacoes where NomeLoja = ? order by Cod_Movimentacao desc";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
               pstm.setString(1, NomeLoja);
                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                    pDTO.setCod_Movimentacao(rs.getInt("Cod_Movimentacao"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                    pDTO.setQtde(rs.getInt("Quantidade"));
                    pDTO.setTipo(rs.getString("Tipo"));
                    pDTO.setData(rs.getString("Data"));
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;
}


   public ArrayList<MovimentacaoDTO> ListarMovimentacaoTipo(String NomeLoja, String Tipo, String Nome, String Data){
 
            String sql = "select * from Movimentacoes where NomeLoja = ? and NomeProduto LIKE ? and Tipo LIKE ? and Data LIKE ? order by Cod_Movimentacao desc";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                pstm.setString(1, NomeLoja);
                pstm.setString(3, "%"+Tipo+"%");
                pstm.setString(2, "%"+Nome+"%");
                 pstm.setString(4, "%"+Data+"%");


                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                    pDTO.setCod_Movimentacao(rs.getInt("Cod_Movimentacao"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                    pDTO.setQtde(rs.getInt("Quantidade"));
                    pDTO.setTipo(rs.getString("Tipo"));
                    pDTO.setData(rs.getString("Data"));
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;

            
   }
   
         public ArrayList<MovimentacaoDTO> ListarMovimentacaoData(String NomeLoja, String d){
 
            String sql = "Select * from Movimentacoes where NomeLoja = ? and Data LIKE ? order by Cod_Movimentacao desc";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
               pstm.setString(1, NomeLoja);
               pstm.setString(2, d);
              
                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                    pDTO.setCod_Movimentacao(rs.getInt("Cod_Movimentacao"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                    pDTO.setQtde(rs.getInt("Quantidade"));
                    pDTO.setTipo(rs.getString("Tipo"));
                    pDTO.setData(rs.getString("Data"));
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;
}
         
         public ArrayList<MovimentacaoDTO> ListarProdutoSaida(String NomeLoja){
 
            String sql = "Select sum(Quantidade), NomeProduto from Movimentacoes where Tipo = 'SAIDA' and NomeLoja = ?  group by NomeProduto order by 1 desc;";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                
                
                pstm.setString(1, NomeLoja);
                 
       


                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                   pDTO.setSaidaQdte(rs.getInt("sum(Quantidade)"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                   
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;

            
   }
         
               public ArrayList<MovimentacaoDTO> ListarNomeProdutoSaida(String NomeLoja, String NomeProduto){
 
            String sql = "Select sum(Quantidade), NomeProduto from Movimentacoes where Tipo = 'SAIDA' and NomeLoja = ? and NomeProduto LIKE ? group by NomeProduto order by 1 desc;";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                
                
                pstm.setString(1, NomeLoja);

                pstm.setString(2, "%"+NomeProduto+"%");
               

                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                   pDTO.setSaidaQdte(rs.getInt("sum(Quantidade)"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                   
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;

            
   }
                        public ArrayList<MovimentacaoDTO> ListarProdutoEntrada(String NomeLoja){
 
            String sql = "Select sum(Quantidade), NomeProduto from Movimentacoes where Tipo = 'ENTRADA' and NomeLoja = ?  group by NomeProduto order by 1 desc;";
            conn = new ConexaoDAO().conectaBD();
            try {
                pstm = conn.prepareStatement(sql);
                
                
                pstm.setString(1, NomeLoja);
       


                rs = pstm.executeQuery();
                
                while(rs.next()){
                    MovimentacaoDTO pDTO = new MovimentacaoDTO();
                   pDTO.setSaidaQdte(rs.getInt("sum(Quantidade)"));
                    pDTO.setNomeProduto(rs.getString("NomeProduto"));
                   
                    
                    
                    
                    lista.add(pDTO);
                    
                }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return lista;
                        }
        
}
