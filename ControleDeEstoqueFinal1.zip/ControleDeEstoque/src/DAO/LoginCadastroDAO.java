/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.LoginCadastroDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Allan
 */
public class LoginCadastroDAO {
        Connection conn;
    public ResultSet Autenticacao(LoginCadastroDTO lDTO){
            conn = new ConexaoDAO().conectaBD();
            try {
                String sql = "select * from CadastroLogin where Login = ? and Senha = ? ";
                PreparedStatement pstm = conn.prepareStatement(sql);
                pstm.setString(1, lDTO.getLogin());
                pstm.setString(2, lDTO.getSenha());
                ResultSet rs;
                rs = pstm.executeQuery();
                return rs;
                
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"UsuarioDAO"+e);
                return null;
                
        }
    }
}
