
package DAO;

import DTO.FornecedorDTO;
import View.frmFornecedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class FornecedorDAO {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<FornecedorDTO> lista = new ArrayList<>();
  public void CadastrarFornecedor(FornecedorDTO objfDTO){
       String sql = "insert into Fornecedor (Nome, InscricaoEstadual, Telefone, Email, CNPJ, Endereco, NomeLoja) values (?, ?, ?, ?, ?, ?, ?)";
       conn = new ConexaoDAO().conectaBD();
       
       try {
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, objfDTO.getNome());
           pstm.setString(2,objfDTO.getInsc());
           pstm.setString(3, objfDTO.getTel());
           pstm.setString(4, objfDTO.getEmail());
           pstm.setString(5, objfDTO.getCnpj());
           pstm.setString(6, objfDTO.getEnd());
           pstm.setString(7, objfDTO.getLojaAtual());
           
          
           
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"FornecedorDAO" + e);
       }
       
      
       
  }
  
public FornecedorDTO PesquisarFornecedor(int Cod){
          String sql = "SELECT * FROM Fornecedor WHERE Cod_Fornecedor = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = this.conn.prepareStatement(sql);
              pstm.setInt(1, Cod);
              rs = pstm.executeQuery();
              FornecedorDTO fDTO = new FornecedorDTO();
              rs.first();
              if(rs.first()){
              fDTO.setCod_Fornecedor(Cod);
              fDTO.setNome(rs.getString("Nome"));
              fDTO.setInsc(rs.getString("InscricaoEstadual"));
              fDTO.setTel(rs.getString("Telefone"));
              fDTO.setEmail(rs.getString("Email"));
              fDTO.setCnpj(rs.getString("CNPJ"));
              fDTO.setEnd(rs.getString("Endereco"));
              return fDTO;
              }else{
                  
                  JOptionPane.showMessageDialog(null, "Fornecedor não encontrado");

                  
              }
          } catch (Exception e) {
              return null;
          }
        return null;
          
      }
  public void ExcluirFornecedor(FornecedorDTO fDTO){
          String sql = "DElETE  FROM Fornecedor WHERE Cod_Fornecedor = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              pstm.setInt(1, fDTO.getCod_Fornecedor());

              pstm.execute();
              pstm.close();
              
              
              
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null,"ExcluirLojaDAO" +e);
          }
          
      }
    public void AlterarFornecedor(FornecedorDTO objfDTO){
               String sql = "update Fornecedor set Nome = ?, InscricaoEstadual = ?, Telefone = ?, Email = ?, CNPJ = ?, Endereco = ? where Cod_Fornecedor = ?";
               conn = new ConexaoDAO().conectaBD();
       
       try {
           
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, objfDTO.getNome());
           pstm.setString(2, objfDTO.getInsc());
           pstm.setString(3, objfDTO.getTel());
           pstm.setString(4, objfDTO.getEmail());
           pstm.setString(5, objfDTO.getCnpj());
           pstm.setString(6, objfDTO.getEnd());
           pstm.setInt(7, objfDTO.getCod_Fornecedor());
           
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"FornecedorDAO" + e);
       }
   }
    public ResultSet ListarFornecedor(){
        conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM Fornecedor where NomeLoja = ? ORDER BY Nome ";
        try {
            FornecedorDTO f = new FornecedorDTO();
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, f.getLojaAtual());
            return pstm.executeQuery();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
return null;
    }
    
    
    

  
    public ArrayList  <FornecedorDTO> ListaTabela(String NomeLoja){
        String sql = "select * from Fornecedor where NomeLoja = ?";
        conn = new ConexaoDAO().conectaBD();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, NomeLoja);
           
            rs = pstm.executeQuery();
            
            while(rs.next()){
                FornecedorDTO pDTO = new FornecedorDTO();
                pDTO.setCod_Fornecedor(rs.getInt("Cod_Fornecedor"));
                pDTO.setNome(rs.getString("Nome"));
                pDTO.setInsc(rs.getString("InscricaoEstadual"));
                pDTO.setTel(rs.getString("Telefone"));
                pDTO.setEmail(rs.getString("Email"));
                pDTO.setCnpj(rs.getString("CNPJ"));
                pDTO.setEnd(rs.getString("Endereco"));
                
              lista.add(pDTO);
                
                
            }
            
        } catch (Exception e) {
        }
        return lista;
    }
    
    
     public ArrayList  <FornecedorDTO> ListaTabelaPeloNomeCNPJ(String NomeLoja,String Nome, String CNPJ, String Insc){
        String sql = "select * from Fornecedor where NomeLoja = ? and Nome LIKE ? and CNPJ LIKE ? and InscricaoEstadual LIKE ? ";
        conn = new ConexaoDAO().conectaBD();
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, NomeLoja);
            pstm.setString(2, "%"+Nome+"%");
            pstm.setString(3, "%"+CNPJ+"%");
             pstm.setString(4, "%"+Insc+"%");
            
            rs = pstm.executeQuery();
            
            while(rs.next()){
                                FornecedorDTO pDTO = new FornecedorDTO();
                pDTO.setCod_Fornecedor(rs.getInt("Cod_Fornecedor"));
                pDTO.setNome(rs.getString("Nome"));
                pDTO.setInsc(rs.getString("InscricaoEstadual"));
                pDTO.setTel(rs.getString("Telefone"));
                pDTO.setEmail(rs.getString("Email"));
                pDTO.setCnpj(rs.getString("CNPJ"));
                pDTO.setEnd(rs.getString("Endereco"));
                
              lista.add(pDTO);
                
                
            }
            
        } catch (Exception e) {
        }
        return lista;
    }
     
     public void ExcluirFornecedorLoja(FornecedorDTO pDTO){
          String sql = "DElETE  FROM Fornecedor WHERE NomeLoja = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              
              pstm.setString(1, pDTO.getLojaAtual());
              
              pstm.execute();
              pstm.close();
              
              
              
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
          }
          
      }
}
