
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoDAO {
    public Connection conectaBD(){      //Metodo com retorno do tipo connection
        Connection  conn = null;       //Iniciando a variavel
        try {
            String url = "jdbc:mysql://localhost:3306/ControleEstoque?user=root&password=Allan3004";  //String para conectar no banco 
            conn = DriverManager.getConnection(url); //Cocretizando a conexao
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"ConexaoDAO" + e.getMessage());
        }
        return conn;
    }
}
