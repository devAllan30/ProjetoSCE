
package DAO;

import DTO.CadastroDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


public class CadastroDAO {
Connection conn;
PreparedStatement pstm;

    public void CadastrarUsuario (CadastroDTO objcDTO){     //Metodo de cadastrar chamando a classe e os seu objeto
       String sql = "insert into Usuario (Login, Senha) values (?, ?)"; //String de para inserir os valores na tabela
       conn = new ConexaoDAO().conectaBD(); //chamando a conexao
       
       try {
           pstm = conn.prepareStatement(sql); //preparando a conexao e passando a string como parametro
           
           pstm.setString(1, objcDTO.getLogin()); //setando os valores na tabela
           pstm.setString(2, objcDTO.getSenha()); 
          
           
           pstm.execute();   //Executando 
           pstm.close();     //Fechando
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"ProdutoDAO" + e);
       }
}
}