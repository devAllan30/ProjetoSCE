
package DAO;

import DTO.LojaDTO;
import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class UsuarioDAO {
    Connection conn;
    public ResultSet Autenticacao(UsuarioDTO uDTO){
            conn = new ConexaoDAO().conectaBD();
            try {
                String sql;
                sql = "select * from usuario where Login = ? and Senha = ? ";
                PreparedStatement pstm = conn.prepareStatement(sql);
                pstm.setString(1, uDTO.getLogin());
                pstm.setString(2, uDTO.getSenha());
                ResultSet rs;
                rs = pstm.executeQuery();
                return rs;
                
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"UsuarioDAO"+e);
                return null;
                
        }
    }

   
    
    
      
    
}
