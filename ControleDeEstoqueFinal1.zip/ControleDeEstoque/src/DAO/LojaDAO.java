
package DAO;

import DTO.LojaAtualDTO;
import DTO.LojaDTO;
import DTO.ProdutoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class LojaDAO {
    Connection conn;
    PreparedStatement pstm;
      ResultSet rs;
   public void CadastrarLoja (LojaDTO objLDTO){
       String sql = "insert into Loja (Nome, Telefone, Endereco, Email, CNPJ, CapacidadeEstoque) values (?, ?,?, ?, ?, ?)";
       conn = new ConexaoDAO().conectaBD();
       
       try {
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, objLDTO.getNome());
           pstm.setString(2, objLDTO.getTelefone());
           pstm.setString(3, objLDTO.getEndereco());
           pstm.setString(4, objLDTO.getEmail());
           pstm.setString(5, objLDTO.getCNPJ());
           pstm.setInt(6, objLDTO.getCapacidadeEstoque());
           
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"FuncionarioDAO" + e);
       }
   }
    
  
      public LojaDTO PesquisarLoja(String nome){
          String sql = "SELECT * FROM Loja WHERE Nome = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = this.conn.prepareStatement(sql);
              pstm.setString(1, nome);
              rs = pstm.executeQuery(); //Procuro a linha Cod e selecionou
             
              
              LojaDTO lDTO = new LojaDTO();
              rs.first();
              if(rs.first()){
             
              
              
              lDTO.setNome(rs.getString("Nome"));
              lDTO.setTelefone(rs.getString("Telefone"));
              lDTO.setEndereco(rs.getString("Endereco"));
              lDTO.setEmail(rs.getString("Email"));
              lDTO.setCNPJ(rs.getString("CNPJ"));
              lDTO.setCapacidadeEstoque(rs.getInt("CapacidadeEstoque"));
              return lDTO;
              }else{
                  JOptionPane.showMessageDialog(null, "Loja não encontrada");
              }
              
          } catch (Exception e) {
              return null;
          }
        return null;
          
      }
           
      
      
      public void ExcluirLoja(LojaDTO lDTO){
          String sql = "DElETE  FROM Loja WHERE Nome = ?";
          conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              pstm.setString(1, lDTO.getNome());

              pstm.execute();
              pstm.close();
              
              
              
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null,"ExcluirLojaDAO" +e);
          }
          
      }
         
      
      
      
      
      
      
      
      public void AlterarLoja(LojaDTO objLDTO){
            String sql = "update Loja set  Nome = ?, Telefone = ?, Endereco = ?, Email = ?, CNPJ = ?, CapacidadeEstoque = ? where Cod_Loja = ?";
            conn = new ConexaoDAO().conectaBD();
      
       try {
           pstm = conn.prepareStatement(sql);
           pstm.setString(1, objLDTO.getNome());
           pstm.setString(2, objLDTO.getTelefone());
           pstm.setString(3, objLDTO.getEndereco());
           pstm.setString(4, objLDTO.getEmail());
           pstm.setString(5, objLDTO.getCNPJ());
           pstm.setInt(6, objLDTO.getCapacidadeEstoque());
           pstm.setInt(7,objLDTO.getCod_Loja());
           
           
           pstm.execute();
           pstm.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"AlterarLojaDAO" + e);
       }
   }
       public ResultSet ListarLoja(){
        conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM Loja  ORDER BY Nome";
        try {
            pstm = conn.prepareStatement(sql);
            return pstm.executeQuery();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
return null;
    }
       
   public LojaAtualDTO PegarLoja(int cod){
          String sql = "SELECT * FROM histloja WHERE idhistloja = ?";
          PreparedStatement pstm;
          ResultSet rs;
         Connection conn = new ConexaoDAO().conectaBD();
          try {
              pstm = conn.prepareStatement(sql);
              pstm.setInt(1, cod);
              rs = pstm.executeQuery();
              
              LojaAtualDTO pDTO = new LojaAtualDTO();
              rs.first();
              if(rs.first()){
              
              pDTO.setId(rs.getInt("idhistloja"));
              pDTO.setLoja(rs.getString("Nome"));
             
              return pDTO;
              
              }else{
                  JOptionPane.showMessageDialog(null, "Loja não encontrada");
                  
                  
              }
          } catch (Exception e) {
              return null;
          }
         return null;
          
      } 

}
    
     
   

